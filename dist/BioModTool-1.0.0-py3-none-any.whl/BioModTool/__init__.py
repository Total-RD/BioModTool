"""
BioModTool
"""

__version__ = "1.0.0"
__authors__ = 'Clemence Dupont Thibert, Sylvaine Roy, Gilles Curien, Maxime Durot'
__corresponding_author_email__ = 'maxime.durot@totalenergies.com'